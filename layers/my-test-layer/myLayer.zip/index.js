
const hello = () => {
    console.log('Hello from lambda layer!');
}

module.exports = {
    hello
}